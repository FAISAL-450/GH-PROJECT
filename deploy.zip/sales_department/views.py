from django.shortcuts import render
def sales_department_view(request):
    return render(request, 'sales_department/sales_department.html')  # Corrected path

